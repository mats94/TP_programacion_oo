from django.apps import AppConfig


class PeliculaConfig(AppConfig):
    name = 'pelicula'
